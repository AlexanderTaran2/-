const { v4: uuidv4 } = require('uuid');
const fs = require('fs').promises;
const path = require('path');

const postsFile = path.join(__dirname, '../data/posts.json');

class Post {
    static async findAll() {
        try {
            const data = await fs.readFile(postsFile, 'utf8');
            return JSON.parse(data);
        } catch (error) {
            return [];
        }
    }

    static async findById(id) {
        const posts = await this.findAll();
        return posts.find(post => post.id === id);
    }

    static async create(postData) {
        const posts = await this.findAll();
        const newPost = {
            id: uuidv4(),
            ...postData,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
        };
        
        posts.push(newPost);
        await this.saveAll(posts);
        return newPost;
    }

    static async update(id, updateData) {
        const posts = await this.findAll();
        const postIndex = posts.findIndex(post => post.id === id);
        
        if (postIndex === -1) return null;
        
        posts[postIndex] = {
            ...posts[postIndex],
            ...updateData,
            updatedAt: new Date().toISOString()
        };
        
        await this.saveAll(posts);
        return posts[postIndex];
    }

    static async delete(id) {
        const posts = await this.findAll();
        const filteredPosts = posts.filter(post => post.id !== id);
        
        if (posts.length === filteredPosts.length) return false;
        
        await this.saveAll(filteredPosts);
        return true;
    }

    static async search(query) {
        const posts = await this.findAll();
        const searchTerm = query.toLowerCase();
        
        return posts.filter(post => 
            post.title.toLowerCase().includes(searchTerm) ||
            post.content.toLowerCase().includes(searchTerm) ||
            post.author.toLowerCase().includes(searchTerm) ||
            post.tags.some(tag => tag.toLowerCase().includes(searchTerm))
        );
    }

    static async saveAll(posts) {
        await fs.writeFile(postsFile, JSON.stringify(posts, null, 2));
    }
}

module.exports = Post;