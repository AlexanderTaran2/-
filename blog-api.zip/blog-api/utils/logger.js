const fs = require('fs').promises;
const path = require('path');

const logFile = path.join(__dirname, '../logs/errors.log');

class Logger {
    static async ensureLogDirectory() {
        const logDir = path.dirname(logFile);
        try {
            await fs.access(logDir);
        } catch {
            await fs.mkdir(logDir, { recursive: true });
        }
    }

    static async log(level, message, meta = {}) {
        await this.ensureLogDirectory();
        
        const logEntry = {
            timestamp: new Date().toISOString(),
            level,
            message,
            ...meta
        };

        console.log(`[${level.toUpperCase()}] ${message}`);
        
        try {
            await fs.appendFile(logFile, JSON.stringify(logEntry) + '\n');
        } catch (error) {
            console.error('Failed to write to log file:', error);
        }
    }

    static info(message, meta) {
        this.log('info', message, meta);
    }

    static error(message, meta) {
        this.log('error', message, meta);
    }

    static warn(message, meta) {
        this.log('warn', message, meta);
    }
}

module.exports = Logger;