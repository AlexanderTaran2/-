const express = require('express');
const Post = require('../models/Post');
const { validatePost } = require('../middleware/validation');
const { verifyToken } = require('../middleware/auth');
const logger = require('../utils/logger');

const router = express.Router();

// GET /api/posts - получить все статьи
router.get('/', async (req, res, next) => {
    try {
        const posts = await Post.findAll();
        res.json({
            success: true,
            data: {
                posts,
                count: posts.length
            }
        });
    } catch (error) {
        logger.error('Error fetching posts:', error);
        next(error);
    }
});

// GET /api/posts/search - поиск статей
router.get('/search', async (req, res, next) => {
    try {
        const { q } = req.query;
        
        if (!q) {
            return res.status(400).json({
                success: false,
                error: {
                    code: 400,
                    message: 'Search query is required'
                }
            });
        }

        const posts = await Post.search(q);
        res.json({
            success: true,
            data: {
                posts,
                count: posts.length,
                query: q
            }
        });
    } catch (error) {
        logger.error('Error searching posts:', error);
        next(error);
    }
});

// GET /api/posts/:id - получить статью по ID
router.get('/:id', async (req, res, next) => {
    try {
        const post = await Post.findById(req.params.id);
        
        if (!post) {
            return res.status(404).json({
                success: false,
                error: {
                    code: 404,
                    message: 'Post not found'
                }
            });
        }

        res.json({
            success: true,
            data: { post }
        });
    } catch (error) {
        logger.error(`Error fetching post ${req.params.id}:`, error);
        next(error);
    }
});

// POST /api/posts - создать новую статью (требует аутентификации)
router.post('/', verifyToken, validatePost, async (req, res, next) => {
    try {
        const newPost = await Post.create(req.body);
        
        logger.info(`New post created: ${newPost.id} by user ${req.user.userId}`);
        
        res.status(201).json({
            success: true,
            data: { post: newPost }
        });
    } catch (error) {
        logger.error('Error creating post:', error);
        next(error);
    }
});

// PUT /api/posts/:id - обновить статью (требует аутентификации)
router.put('/:id', verifyToken, validatePost, async (req, res, next) => {
    try {
        const updatedPost = await Post.update(req.params.id, req.body);
        
        if (!updatedPost) {
            return res.status(404).json({
                success: false,
                error: {
                    code: 404,
                    message: 'Post not found'
                }
            });
        }

        logger.info(`Post updated: ${req.params.id} by user ${req.user.userId}`);
        
        res.json({
            success: true,
            data: { post: updatedPost }
        });
    } catch (error) {
        logger.error(`Error updating post ${req.params.id}:`, error);
        next(error);
    }
});

// DELETE /api/posts/:id - удалить статью (требует аутентификации)
router.delete('/:id', verifyToken, async (req, res, next) => {
    try {
        const deleted = await Post.delete(req.params.id);
        
        if (!deleted) {
            return res.status(404).json({
                success: false,
                error: {
                    code: 404,
                    message: 'Post not found'
                }
            });
        }

        logger.info(`Post deleted: ${req.params.id} by user ${req.user.userId}`);
        
        res.status(204).send();
    } catch (error) {
        logger.error(`Error deleting post ${req.params.id}:`, error);
        next(error);
    }
});

module.exports = router;