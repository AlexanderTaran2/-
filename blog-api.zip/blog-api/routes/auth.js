const express = require('express');
const AuthMiddleware = require('../middleware/auth');
const { validateAuth } = require('../middleware/validation');

const router = express.Router();

// POST /api/auth/register - регистрация
router.post('/register', validateAuth, AuthMiddleware.register);

// POST /api/auth/login - вход
router.post('/login', validateAuth, AuthMiddleware.login);

// GET /api/auth/me - данные текущего пользователя
router.get('/me', AuthMiddleware.getCurrentUser);

module.exports = router;