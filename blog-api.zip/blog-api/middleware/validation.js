const Joi = require('joi');
const logger = require('../utils/logger');

// Схемы валидации
const postSchema = Joi.object({
    title: Joi.string().min(3).max(255).required(),
    content: Joi.string().min(10).required(),
    author: Joi.string().min(2).max(100).required(),
    tags: Joi.array().items(Joi.string().min(1)).optional().default([])
});

const authSchema = Joi.object({
    email: Joi.string().email().required(),
    password: Joi.string().min(6).required(),
    name: Joi.string().min(2).max(100).optional()
});

// Middleware валидации
const validatePost = (req, res, next) => {
    const { error } = postSchema.validate(req.body);
    
    if (error) {
        return res.status(400).json({
            success: false,
            error: {
                code: 400,
                message: 'Validation error',
                details: error.details.map(detail => detail.message)
            }
        });
    }
    next();
};

const validateAuth = (req, res, next) => {
    const { error } = authSchema.validate(req.body);
    
    if (error) {
        return res.status(400).json({
            success: false,
            error: {
                code: 400,
                message: 'Validation error',
                details: error.details.map(detail => detail.message)
            }
        });
    }
    next();
};

// Глобальный обработчик ошибок
const errorHandler = (err, req, res, next) => {
    logger.error('Unhandled error:', {
        error: err.message,
        stack: err.stack,
        url: req.url,
        method: req.method
    });

    // Joi validation errors
    if (err.isJoi) {
        return res.status(400).json({
            success: false,
            error: {
                code: 400,
                message: 'Validation error',
                details: err.details.map(detail => detail.message)
            }
        });
    }

    // JWT errors
    if (err.name === 'JsonWebTokenError') {
        return res.status(401).json({
            success: false,
            error: {
                code: 401,
                message: 'Invalid token'
            }
        });
    }

    // Default error
    res.status(500).json({
        success: false,
        error: {
            code: 500,
            message: 'Internal server error'
        }
    });
};

module.exports = {
    validatePost,
    validateAuth,
    errorHandler
};