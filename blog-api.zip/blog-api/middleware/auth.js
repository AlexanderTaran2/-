const jwt = require('jsonwebtoken');
const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key';

// Mock пользователи (в реальном приложении - база данных)
const users = [
    {
        id: 1,
        email: 'admin@blog.com',
        password: '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', // password
        name: 'Admin User'
    }
];

class AuthMiddleware {
    static generateToken(user) {
        return jwt.sign(
            { userId: user.id, email: user.email },
            JWT_SECRET,
            { expiresIn: '24h' }
        );
    }

    static verifyToken(req, res, next) {
        const token = req.header('Authorization')?.replace('Bearer ', '');
        
        if (!token) {
            return res.status(401).json({
                success: false,
                error: {
                    code: 401,
                    message: 'Access denied. No token provided.'
                }
            });
        }

        try {
            const decoded = jwt.verify(token, JWT_SECRET);
            req.user = decoded;
            next();
        } catch (error) {
            return res.status(400).json({
                success: false,
                error: {
                    code: 400,
                    message: 'Invalid token.'
                }
            });
        }
    }

    static async register(req, res, next) {
        try {
            const { email, password, name } = req.body;
            
            // Проверка существующего пользователя
            const existingUser = users.find(user => user.email === email);
            if (existingUser) {
                return res.status(400).json({
                    success: false,
                    error: {
                        code: 400,
                        message: 'User already exists'
                    }
                });
            }

            // В реальном приложении хешируем пароль
            const newUser = {
                id: users.length + 1,
                email,
                password, // В реальном приложении: await bcrypt.hash(password, 10)
                name
            };

            users.push(newUser);
            
            const token = this.generateToken(newUser);
            
            res.status(201).json({
                success: true,
                data: {
                    user: {
                        id: newUser.id,
                        email: newUser.email,
                        name: newUser.name
                    },
                    token
                }
            });
        } catch (error) {
            next(error);
        }
    }

    static async login(req, res, next) {
        try {
            const { email, password } = req.body;
            
            const user = users.find(user => user.email === email);
            if (!user) {
                return res.status(400).json({
                    success: false,
                    error: {
                        code: 400,
                        message: 'Invalid credentials'
                    }
                });
            }

            // В реальном приложении: await bcrypt.compare(password, user.password)
            if (password !== 'password') {
                return res.status(400).json({
                    success: false,
                    error: {
                        code: 400,
                        message: 'Invalid credentials'
                    }
                });
            }

            const token = this.generateToken(user);
            
            res.json({
                success: true,
                data: {
                    user: {
                        id: user.id,
                        email: user.email,
                        name: user.name
                    },
                    token
                }
            });
        } catch (error) {
            next(error);
        }
    }

    static getCurrentUser(req, res) {
        const user = users.find(user => user.id === req.user.userId);
        
        if (!user) {
            return res.status(404).json({
                success: false,
                error: {
                    code: 404,
                    message: 'User not found'
                }
            });
        }

        res.json({
            success: true,
            data: {
                user: {
                    id: user.id,
                    email: user.email,
                    name: user.name
                }
            }
        });
    }
}

module.exports = AuthMiddleware;
module.exports = AuthMiddleware;